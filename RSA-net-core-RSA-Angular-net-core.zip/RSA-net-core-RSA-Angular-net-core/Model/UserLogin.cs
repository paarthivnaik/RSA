﻿namespace RSA_Angular_.NET_CORE.Model
{
    public class UserLogin
    {
        public string userData { get; set; }
    }
}
